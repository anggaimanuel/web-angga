<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Galeri Foto</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>
<body>

<nav class="navbar navbar-expand-lg bg-secondary">
  <div class="container">
    <a class="navbar-brand" href="index.php">Website Galeri Foto</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse mt-2" id="navbarNavAltMarkup">
      <div class="navbar-nav me-auto">

      </div>
      <a href="register.php" class="btn btn-outline-light m-1">Daftar</a>
      <a href="login.php" class="btn btn-outline-light m-1">Masuk</a>
    </div>
  </div>
</nav>

<div class="container mt-3">
    <div class="row">
        <div class="col">
            <div class="col-md-3">
                <div class="card">
                    <img src="assets/img/tuna.jpg" class="card-img-top" title="height: 12rem;">
                    <div class="card-footer text-center">
                        <a href="login.php" class="fa fa-thumbs-up m-1"> like </a>
                        <a href="login.php" class="fa fa-thumbs-down m-1"> dislike </a>
                        <a href="login.php" class="fa-regular fa-comment"> comment </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="d-flex justify-content-center border-top mt-3 bg-secondary fixed-bottom">
    <p>&copy; UKK RPL 2024 | FADEL SUYAGA</p>
</footer>

<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>
