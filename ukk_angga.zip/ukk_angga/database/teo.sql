-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Feb 2024 pada 05.16
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `#mysql50#tugas praktikum`
--
CREATE DATABASE IF NOT EXISTS `#mysql50#tugas praktikum` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `#mysql50#tugas praktikum`;
--
-- Database: `Bioskop`
--
CREATE DATABASE IF NOT EXISTS `Bioskop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Bioskop`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bioskop`
--

CREATE TABLE `bioskop` (
  `kode_film` varchar(10) DEFAULT NULL,
  `jenis` varchar(15) DEFAULT NULL,
  `judul` varchar(20) DEFAULT NULL,
  `jumlah_keping` int(5) DEFAULT NULL,
  `jumlah_film` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bioskop`
--

INSERT INTO `bioskop` (`kode_film`, `jenis`, `judul`, `jumlah_keping`, `jumlah_film`) VALUES
('A01', 'Action', 'Spiderman', 2, 3),
('A02', 'Action', 'Spiderman2', 2, 5),
('D01', 'Drama', 'Love Story', 2, 3),
('H01', 'Horor', 'Evil Deadth Rise', 2, 2);
--
-- Database: `cookies`
--
CREATE DATABASE IF NOT EXISTS `cookies` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cookies`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('', 'da39a3ee5e6b4b0d3255bfef95601890afd80709'),
('admin', '8cb2237d0679ca88db6464eac60da96345513964');
--
-- Database: `crud`
--
CREATE DATABASE IF NOT EXISTS `crud` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `crud`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `employees`
--

INSERT INTO `employees` (`id`, `name`, `address`, `salary`) VALUES
(1, 'Nisa', 'kampung Baru', 2000000),
(2, 'DuniaGayamu', 'medan\r\nJl. cik ditiro no.1d lantai 4', 123);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `PASSWORD`) VALUES
(3, 'nisa', '$2y$10$t3VwHAA8TPF18KjH1unDPeu');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Database: `crudaja`
--
CREATE DATABASE IF NOT EXISTS `crudaja` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `crudaja`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cape`
--

CREATE TABLE `cape` (
  `id` int(11) NOT NULL,
  `NamaBuku` varchar(255) NOT NULL,
  `Pengarang` varchar(255) NOT NULL,
  `Tahunterbit` varchar(5) NOT NULL,
  `JumlahHalaman` int(5) NOT NULL,
  `Penerbit` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_buku`
--

CREATE TABLE `tabel_buku` (
  `id` int(11) NOT NULL,
  `judul_buku` varchar(255) NOT NULL,
  `nama_pengarang` varchar(255) NOT NULL,
  `tahun_terbit` varchar(5) NOT NULL,
  `jlh_halaman` int(5) NOT NULL,
  `penerbit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_buku`
--

INSERT INTO `tabel_buku` (`id`, `judul_buku`, `nama_pengarang`, `tahun_terbit`, `jlh_halaman`, `penerbit`) VALUES
(1, 'GAK tau', 'jamal', '2005', 12, 'jamal'),
(2, 'jamal', 'jamal', '2005', 12, '123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `cape`
--
ALTER TABLE `cape`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tabel_buku`
--
ALTER TABLE `tabel_buku`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `cape`
--
ALTER TABLE `cape`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tabel_buku`
--
ALTER TABLE `tabel_buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `crudd`
--
CREATE DATABASE IF NOT EXISTS `crudd` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `crudd`;
--
-- Database: `crudoop`
--
CREATE DATABASE IF NOT EXISTS `crudoop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `crudoop`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_buku`
--

CREATE TABLE `table_buku` (
  `id_buku` int(10) NOT NULL,
  `judul_buku` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `pengarang` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `tanggal_terbit` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `table_buku`
--
ALTER TABLE `table_buku`
  ADD PRIMARY KEY (`id_buku`);
--
-- Database: `data_pribadi`
--
CREATE DATABASE IF NOT EXISTS `data_pribadi` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `data_pribadi`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_pribadi`
--

CREATE TABLE `data_pribadi` (
  `Nip` int(5) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `Tgl_lahir` date DEFAULT NULL,
  `sex` enum('p','w') DEFAULT NULL,
  `alamat` varchar(35) DEFAULT NULL,
  `kota` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `dbpenjualan`
--
CREATE DATABASE IF NOT EXISTS `dbpenjualan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbpenjualan`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang`
--

CREATE TABLE `tb_barang` (
  `kode_barang` int(15) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_beli` int(15) NOT NULL,
  `harga_jual` int(15) NOT NULL,
  `jumlah_barang` int(15) NOT NULL,
  `satuan` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_barang`
--

INSERT INTO `tb_barang` (`kode_barang`, `nama_barang`, `harga_beli`, `harga_jual`, `jumlah_barang`, `satuan`) VALUES
(11, 'Kopi', 4000, 5000, 100, 'PAK'),
(22, 'Gula', 6000, 7000, 100, 'PAK'),
(33, 'Kecap', 5000, 7000, 100, 'Botol'),
(44, 'Cuka', 2000, 3000, 100, 'Botol'),
(55, 'Susu', 5000, 6000, 100, 'Kaleng'),
(66, 'Garam', 2000, 3000, 100, 'PAK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_customer`
--

CREATE TABLE `tb_customer` (
  `code` text NOT NULL,
  `customer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_customer`
--

INSERT INTO `tb_customer` (`code`, `customer`) VALUES
('001', 'DORA'),
('002', 'PIRDA'),
('003', 'FILDZA'),
('004', 'CELSI');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_karyawan`
--

CREATE TABLE `tb_karyawan` (
  `kode_karyawan` text NOT NULL,
  `nama_karyawan` text NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_karyawan`
--

INSERT INTO `tb_karyawan` (`kode_karyawan`, `nama_karyawan`, `alamat`) VALUES
('001', 'CINDY', 'JLN.CAPE'),
('002', 'IJA', 'JLN.HATI');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_penjualan`
--

CREATE TABLE `tb_penjualan` (
  `kode` int(11) NOT NULL,
  `customer` varchar(11) NOT NULL,
  `nama_barang` text NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `harga_satuan` int(11) NOT NULL,
  `kuantitas` int(11) NOT NULL,
  `jumlah_barang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_penjualan`
--

INSERT INTO `tb_penjualan` (`kode`, `customer`, `nama_barang`, `harga_barang`, `harga_satuan`, `kuantitas`, `jumlah_barang`) VALUES
(1, 'Dora', 'kopi', 5000, 6000, 5, 100),
(2, 'Pida', 'susu', 5000, 6000, 5, 100);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_stok awal`
--

CREATE TABLE `tb_stok awal` (
  `kode_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `jumah_awal` int(11) NOT NULL,
  `satuan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_stok awal`
--

INSERT INTO `tb_stok awal` (`kode_barang`, `nama_barang`, `harga_beli`, `harga_jual`, `jumah_awal`, `satuan`) VALUES
(11, 'Kopi', 4000, 5000, 100, 'PAK'),
(22, 'Gula', 6000, 7000, 100, 'PAK'),
(33, 'Kecap', 5000, 7000, 100, 'Botol'),
(44, 'Cuka', 2000, 3000, 100, 'Botol'),
(55, 'Susu', 5000, 6000, 100, 'Kaleng'),
(66, 'Garam', 2000, 3000, 100, 'PAK');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indeks untuk tabel `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  ADD PRIMARY KEY (`kode`);

--
-- Indeks untuk tabel `tb_stok awal`
--
ALTER TABLE `tb_stok awal`
  ADD PRIMARY KEY (`kode_barang`);
--
-- Database: `dbperpus`
--
CREATE DATABASE IF NOT EXISTS `dbperpus` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbperpus`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_buku`
--

CREATE TABLE `tabel_buku` (
  `id` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(30) NOT NULL,
  `tahun` year(4) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `harga` int(20) NOT NULL,
  `detail` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tabel_buku`
--

INSERT INTO `tabel_buku` (`id`, `judul`, `pengarang`, `penerbit`, `tahun`, `jumlah`, `harga`, `detail`) VALUES
(1, 'mawar', 'jamal', 'jamal', 2007, 2, 25000, 'wkwkkwkw');
--
-- Database: `dbperpus2`
--
CREATE DATABASE IF NOT EXISTS `dbperpus2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbperpus2`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_buku`
--

CREATE TABLE `tabel_buku` (
  `no` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(30) NOT NULL,
  `tahun` year(4) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `harga` int(20) NOT NULL,
  `detail` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tabel_buku`
--
ALTER TABLE `tabel_buku`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tabel_buku`
--
ALTER TABLE `tabel_buku`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT;
--
-- Database: `db_bloglaravel`
--
CREATE DATABASE IF NOT EXISTS `db_bloglaravel` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_bloglaravel`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `db_daerah`
--
CREATE DATABASE IF NOT EXISTS `db_daerah` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_daerah`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kota`
--

CREATE TABLE `tb_kota` (
  `id_kota` int(20) NOT NULL,
  `nama_kota` varchar(30) NOT NULL,
  `id_provinsi` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_kota`
--

INSERT INTO `tb_kota` (`id_kota`, `nama_kota`, `id_provinsi`) VALUES
(1, 'Jakarta', 1),
(2, 'Semarang', 2),
(3, 'Pati', 2),
(4, 'Bandung', 4),
(6, 'sumatra utara', 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_provinsi`
--

CREATE TABLE `tb_provinsi` (
  `id_provinsi` int(15) NOT NULL,
  `nama_provinsi` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_provinsi`
--

INSERT INTO `tb_provinsi` (`id_provinsi`, `nama_provinsi`) VALUES
(1, 'DKI Jakarta'),
(2, 'Jawa Tengah'),
(3, 'Papua Barat'),
(4, 'Jawa Timur'),
(6, 'sumatra utara');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_kota`
--
ALTER TABLE `tb_kota`
  ADD PRIMARY KEY (`id_kota`),
  ADD KEY `id_provinsi` (`id_provinsi`);

--
-- Indeks untuk tabel `tb_provinsi`
--
ALTER TABLE `tb_provinsi`
  ADD PRIMARY KEY (`id_provinsi`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_kota`
--
ALTER TABLE `tb_kota`
  ADD CONSTRAINT `tb_kota_ibfk_1` FOREIGN KEY (`id_provinsi`) REFERENCES `tb_provinsi` (`id_provinsi`);
--
-- Database: `detailtrans`
--
CREATE DATABASE IF NOT EXISTS `detailtrans` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `detailtrans`;
--
-- Database: `galerifoto`
--
CREATE DATABASE IF NOT EXISTS `galerifoto` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `galerifoto`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_telp` varchar(20) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(2, 'Irawan', 'irawan', 'adminirawan', '085774137284', 'irawan@gmail.com', 'Jl. Raya Kadu Seungit'),
(3, 'Diana', 'diana', '1234', '085788992919', 'Diana@gmail.com', 'Suka Seneng Cikeusik'),
(4, 'Hazwan', 'hazwan', '123', '085787778811', 'hazwan@gmail.com', 'Cikeusik Pandeglang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_category`
--

CREATE TABLE `tb_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_category`
--

INSERT INTO `tb_category` (`category_id`, `category_name`) VALUES
(14, 'Perjalanan'),
(15, 'Bawah Air'),
(16, 'Hewan Peliharaan'),
(17, 'Satwa Liar'),
(18, 'Makanan'),
(19, 'Olahraga'),
(20, 'Fashion'),
(21, 'Seni Rupa'),
(22, 'Dokumenter'),
(23, 'Arsitektur');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_image`
--

CREATE TABLE `tb_image` (
  `image_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `image_description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `image_status` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_image`
--

INSERT INTO `tb_image` (`image_id`, `category_id`, `category_name`, `admin_id`, `admin_name`, `image_name`, `image_description`, `image`, `image_status`, `date_created`) VALUES
(34, 23, 'Arsitektur', 2, 'Irawan', 'Merancang Kota Modern', '<p>Foto ini menggambarkan kegiatan desain perencanaan membuat kota yang modern berdasarkan ramah lingkungan</p>\r\n', 'foto1701141777.jpg', 1, '2023-11-28 04:58:19'),
(35, 23, 'Arsitektur', 2, 'Irawan', 'Merancang Perumahan Elit', '<p>Foto ini menggambarkan kegiatan desain perencanaan membuat Rumah yang modern, nyaman untuk keluarga</p>\r\n', 'foto1701144257.jpg', 1, '2023-11-28 04:04:17'),
(36, 17, 'Satwa Liar', 3, 'Diana', 'Harimau Sumatra', 'Harimau sumatera (Panthera tigris sumatrae) adalah subspesies harimau yang habitat aslinya di pulau Sumatera. Hidup di hutan hujan tropis Sumatera, harimau ini adalah pemakan daging yang ulung. Dengan kecepatan lari hampir 40 mil per jam, mereka adalah predator yang tangguh di alam liar. Kemampuannya berburu, terutama di malam hari, memungkinkan mereka untuk mengintai mangsa dengan diam-diam sebelum menerkam dengan cepat.', 'foto1701147078.jpg', 1, '2023-11-28 04:51:18'),
(37, 17, 'Satwa Liar', 3, 'Diana', 'Badak Jawa', 'Badak Jawa (Rhinoceros sondaicus) adalah jenis satwa langka yang masuk kedalam 25 spesies prioritas utama konservasi Pemerintah Indonesia. Badak Jawa dapat hidup hingga 30-45 tahun di habitat aslinya. Mereka biasa tinggal di hutan hujan dataran rendah, padang rumput basah, dan dataran banjir yang luas. Badak ini merupakan makhluk yang suka menyendiri, kecuali saat pacaran dan saat membesarkan anak.', 'foto1701147926.jpg', 1, '2023-11-28 05:05:26'),
(38, 16, 'Hewan Peliharaan', 3, 'Diana', 'Kucing Angora', 'Anggora adalah kucing dengan ciri khas berbulu panjang yang indah. Anggora memiliki tubuh yang sedang dengan badan berotot yang panjang, ramping, langsing dan elegan. Anggora memiliki hidung yang panjang, kepala yang berbentuk segitiga, serta telinga yang panjang, lebar, dan berbentuk segitiga.', 'foto1701148582.jpg', 1, '2023-11-28 05:16:22'),
(39, 16, 'Hewan Peliharaan', 3, 'Diana', 'Ayam Kampung', 'Ayam kampung adalah kualitas daging nya yang memang lebih unggul di bandingkan dengan daging ayam lain nya, sehingga tidak heran jika rasa nya juga jauh lebih enak di bandingkan ayam lain.', 'foto1701148797.jpg', 1, '2023-11-28 05:19:57'),
(40, 14, 'Perjalanan', 4, 'Hazwan', 'Pantai Carita', 'Pantai Carita merupakan objek wisata yang terletak di Kabupaten Pandeglang. Fasilitas di Pantai Carita cukup lengkap yaitu Banana boat, snorkling, papan seluncur, diving, dan fasilitas lainnya. Banyak juga penginapan-penginapan sepanjang pesisir pantai dan atau rumah-rumah warga yang difungsikan untuk penginapan.', 'foto1701150076.jpg', 1, '2023-11-28 05:41:16'),
(41, 14, 'Perjalanan', 4, 'Hazwan', 'Curug Putri', 'Curug Putri Carita Pandeglang ini unik banget karena terbentuk dari lava yang membeku dan kemudian menjadi aliran sungai dengan batuan cantik.', 'foto1701150304.jpg', 1, '2023-11-28 05:45:04'),
(42, 17, 'Satwa Liar', 3, 'Diana', 'Singa Afrika', 'Singa adalah binatang yang menakutkan , tubuhnya besar, gesit dan garang, buas dan menyeramkan. Singa memiliki taring yang gampang melumatkan mangsanya, punya kuku yang kuat yang mampu menerkam mangsa hingga tak berdaya, dan mencabik- cabiknya. Singa sering digunakan untuk mewakili kekuatan, kegarangan dan kebuasan.', 'foto1701150517.jpg', 1, '2023-11-28 05:48:37');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indeks untuk tabel `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indeks untuk tabel `tb_image`
--
ALTER TABLE `tb_image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tb_category`
--
ALTER TABLE `tb_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `tb_image`
--
ALTER TABLE `tb_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_image`
--
ALTER TABLE `tb_image`
  ADD CONSTRAINT `tb_image_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tb_admin` (`admin_id`),
  ADD CONSTRAINT `tb_image_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `tb_category` (`category_id`);
--
-- Database: `instruktur`
--
CREATE DATABASE IF NOT EXISTS `instruktur` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `instruktur`;
--
-- Database: `kampus`
--
CREATE DATABASE IF NOT EXISTS `kampus` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kampus`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `datamhs`
--

CREATE TABLE `datamhs` (
  `id` int(10) NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama_mahasiswa` varchar(30) NOT NULL,
  `tanggal_daftar` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `datamhs`
--

INSERT INTO `datamhs` (`id`, `nim`, `nama_mahasiswa`, `tanggal_daftar`) VALUES
(6, '23332', 'OCHA', '2023-11-02 02:21:45');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `datamhs`
--
ALTER TABLE `datamhs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `datamhs`
--
ALTER TABLE `datamhs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Database: `kampusku`
--
CREATE DATABASE IF NOT EXISTS `kampusku` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kampusku`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` int(11) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `jurusan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `alamat`, `jurusan`) VALUES
(1, 'pauzan', 'bijei', 'repeel'),
(2, 'adawd', 'dadawdw', 'dadadwadwadw');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);
--
-- Database: `kampusku3`
--
CREATE DATABASE IF NOT EXISTS `kampusku3` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kampusku3`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `universitas`
--

CREATE TABLE `universitas` (
  `nim` int(11) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `jurusan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `universitas`
--
ALTER TABLE `universitas`
  ADD PRIMARY KEY (`nim`);
--
-- Database: `karyawan`
--
CREATE DATABASE IF NOT EXISTS `karyawan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `karyawan`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `datakaryawan`
--

CREATE TABLE `datakaryawan` (
  `id` int(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `gaji` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `datakaryawan`
--

INSERT INTO `datakaryawan` (`id`, `nama`, `alamat`, `gaji`) VALUES
(0, 'cantika', 'jln.pesantren', 1000000),
(0, 'cancan', 'sunggal', 1000000);
--
-- Database: `kmps3`
--
CREATE DATABASE IF NOT EXISTS `kmps3` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kmps3`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `mhsswa`
--

CREATE TABLE `mhsswa` (
  `nim` int(11) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `jurusan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `mhsswa`
--
ALTER TABLE `mhsswa`
  ADD PRIMARY KEY (`nim`);
--
-- Database: `lks computer shop`
--
CREATE DATABASE IF NOT EXISTS `lks computer shop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lks computer shop`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `IdCustomer` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Pin` varchar(50) NOT NULL,
  `Age` int(50) NOT NULL,
  `Address` text NOT NULL,
  `Photo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailtrans`
--

CREATE TABLE `detailtrans` (
  `IdDetailTrans` int(50) NOT NULL,
  `IdTrans` int(50) NOT NULL,
  `IdProduct` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `payment`
--

CREATE TABLE `payment` (
  `IdPayment` int(11) NOT NULL,
  `Payment` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `product`
--

CREATE TABLE `product` (
  `IdProduct` int(11) NOT NULL,
  `Category` varchar(11) NOT NULL,
  `Name` varchar(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Image` varchar(11) NOT NULL,
  `Dscripton` varchar(11) NOT NULL,
  `CreateAT` datetime NOT NULL,
  `UpdateAT` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `trans`
--

CREATE TABLE `trans` (
  `IdTrans` int(11) NOT NULL,
  `IdCustomer` int(11) NOT NULL,
  `IdPayment` int(11) NOT NULL,
  `Date` datetime NOT NULL,
  `SubTotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD KEY `IdCustomer` (`IdCustomer`),
  ADD KEY `Name` (`Name`),
  ADD KEY `Phone` (`Phone`),
  ADD KEY `Email` (`Email`),
  ADD KEY `Pin` (`Pin`),
  ADD KEY `Age` (`Age`),
  ADD KEY `Photo` (`Photo`);

--
-- Indeks untuk tabel `detailtrans`
--
ALTER TABLE `detailtrans`
  ADD KEY `IdDetailTrans` (`IdDetailTrans`),
  ADD KEY `IdDetailTrans_2` (`IdDetailTrans`),
  ADD KEY `IdProduct` (`IdProduct`),
  ADD KEY `Price` (`Price`),
  ADD KEY `Quantity` (`Quantity`);

--
-- Indeks untuk tabel `payment`
--
ALTER TABLE `payment`
  ADD KEY `IdPayment` (`IdPayment`),
  ADD KEY `Payment` (`Payment`);

--
-- Indeks untuk tabel `product`
--
ALTER TABLE `product`
  ADD KEY `IdProduct` (`IdProduct`),
  ADD KEY `IdProduct_2` (`IdProduct`),
  ADD KEY `Name` (`Name`),
  ADD KEY `Stock` (`Stock`),
  ADD KEY `Name_2` (`Name`),
  ADD KEY `Price` (`Price`),
  ADD KEY `Dscripton` (`Dscripton`),
  ADD KEY `UpdateAT` (`UpdateAT`);

--
-- Indeks untuk tabel `trans`
--
ALTER TABLE `trans`
  ADD KEY `IdTrans` (`IdTrans`),
  ADD KEY `IdCustomer` (`IdCustomer`),
  ADD KEY `IdPayment` (`IdPayment`),
  ADD KEY `Date` (`Date`),
  ADD KEY `SubTotal` (`SubTotal`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_2` FOREIGN KEY (`Age`) REFERENCES `payment` (`IdPayment`);

--
-- Ketidakleluasaan untuk tabel `detailtrans`
--
ALTER TABLE `detailtrans`
  ADD CONSTRAINT `detailtrans_ibfk_1` FOREIGN KEY (`IdDetailTrans`) REFERENCES `trans` (`IdTrans`),
  ADD CONSTRAINT `detailtrans_ibfk_2` FOREIGN KEY (`Price`) REFERENCES `product` (`IdProduct`);

--
-- Ketidakleluasaan untuk tabel `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`IdProduct`) REFERENCES `customer` (`IdCustomer`);
--
-- Database: `mapel_kuliah`
--
CREATE DATABASE IF NOT EXISTS `mapel_kuliah` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mapel_kuliah`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `mapel_kuliah`
--

CREATE TABLE `mapel_kuliah` (
  `kode_mk` varchar(20) DEFAULT NULL,
  `nama_mk` varchar(25) DEFAULT NULL,
  `sks` int(5) DEFAULT NULL,
  `semester` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mapel_kuliah`
--

INSERT INTO `mapel_kuliah` (`kode_mk`, `nama_mk`, `sks`, `semester`) VALUES
('PTI447', 'Pratikum Basis Data', 1, 3),
('TIK342', 'Pratikum Basis Data', 1, 3),
('PTI333', 'Basis Data Terdistribusi', 3, 5),
('TIK123', 'Jaringan Komputer', 2, 5),
('TIK333', 'Sistem Operasi', 3, 5),
('PTI123', 'Grafika Multimedia', 3, 5),
('PTI777', 'Sistem Informasi', 2, 3);
--
-- Database: `monn`
--
CREATE DATABASE IF NOT EXISTS `monn` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `monn`;
--
-- Database: `nowsimon`
--
CREATE DATABASE IF NOT EXISTS `nowsimon` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `nowsimon`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `id_anggota` int(2) NOT NULL,
  `nama` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `alamat` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `telpon` varchar(20) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_buku`
--

CREATE TABLE `table_buku` (
  `kode_buku` int(5) NOT NULL,
  `judul_buku` varchar(30) NOT NULL,
  `pengarang` varchar(30) NOT NULL,
  `jenis_buku` varchar(30) NOT NULL,
  `penerbit` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `table_buku`
--

INSERT INTO `table_buku` (`kode_buku`, `judul_buku`, `pengarang`, `jenis_buku`, `penerbit`) VALUES
(11111, 'database', 'Wilian Alexander', 'Cetak', 'CV nanda suyaga');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indeks untuk tabel `table_buku`
--
ALTER TABLE `table_buku`
  ADD PRIMARY KEY (`kode_buku`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id_anggota` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `table_buku`
--
ALTER TABLE `table_buku`
  MODIFY `kode_buku` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11112;
--
-- Database: `oderbarang`
--
CREATE DATABASE IF NOT EXISTS `oderbarang` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `oderbarang`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_costumer`
--

CREATE TABLE `tb_costumer` (
  `costumer_id` int(10) NOT NULL,
  `costumer_name` varchar(25) NOT NULL,
  `addres` varchar(25) NOT NULL,
  `phone` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_costumer`
--

INSERT INTO `tb_costumer` (`costumer_id`, `costumer_name`, `addres`, `phone`) VALUES
(1, 'budi', 'jl.patriot 20 A', '0812345678'),
(2, 'tuty', 'jl.Amal 100', '0821895678');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_order`
--

CREATE TABLE `tb_order` (
  `order_id` int(10) NOT NULL,
  `costumer_id` int(10) NOT NULL,
  `produk_id` int(10) NOT NULL,
  `order_date` date DEFAULT NULL,
  `quantity` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_order`
--

INSERT INTO `tb_order` (`order_id`, `costumer_id`, `produk_id`, `order_date`, `quantity`) VALUES
(1, 1, 1, '2023-01-01', 5),
(2, 2, 2, '2023-02-01', 3),
(3, 1, 3, '2023-03-01', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_produk`
--

CREATE TABLE `tb_produk` (
  `produk_id` int(10) NOT NULL,
  `produk_name` varchar(25) NOT NULL,
  `price` int(9) NOT NULL,
  `deskrisi` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_produk`
--

INSERT INTO `tb_produk` (`produk_id`, `produk_name`, `price`, `deskrisi`) VALUES
(1, 'tablet', 3000000, 'original'),
(2, 'HP', 2500000, 'original'),
(3, 'camera', 800000, 'sekend');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_costumer`
--
ALTER TABLE `tb_costumer`
  ADD PRIMARY KEY (`costumer_id`);

--
-- Indeks untuk tabel `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `costumer_id` (`costumer_id`),
  ADD KEY `produk_id` (`produk_id`);

--
-- Indeks untuk tabel `tb_produk`
--
ALTER TABLE `tb_produk`
  ADD PRIMARY KEY (`produk_id`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_order`
--
ALTER TABLE `tb_order`
  ADD CONSTRAINT `tb_order_ibfk_1` FOREIGN KEY (`costumer_id`) REFERENCES `tb_costumer` (`costumer_id`),
  ADD CONSTRAINT `tb_order_ibfk_2` FOREIGN KEY (`produk_id`) REFERENCES `tb_produk` (`produk_id`);
--
-- Database: `pegawai`
--
CREATE DATABASE IF NOT EXISTS `pegawai` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pegawai`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `NIP` varchar(20) DEFAULT NULL,
  `Nama` varchar(20) DEFAULT NULL,
  `gaji` int(15) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `pendidikan` varchar(15) DEFAULT NULL,
  `jmlh_hari` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`NIP`, `Nama`, `gaji`, `tgl_lahir`, `pendidikan`, `jmlh_hari`) VALUES
('111401005', 'cholik indrianto', 2500000, '1993-01-01', 'DIII', 24),
('111401006', 'Dini Islam', 2500000, '1993-01-31', 'DIII', 22),
('111401010', 'Geubrina Rizky', 2000000, '1990-12-01', 'DIII', 20),
('111401043', 'Richart Valent', 2800000, '1991-11-15', 'S1', 21),
('111401005', 'Angga Eriansyah', 3000000, '1992-07-05', 'S1', 24);
--
-- Database: `pendidikan`
--
CREATE DATABASE IF NOT EXISTS `pendidikan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pendidikan`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `nama_siswa`
--

CREATE TABLE `nama_siswa` (
  `Nim` int(10) NOT NULL,
  `nama` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `Penjualan`
--
CREATE DATABASE IF NOT EXISTS `Penjualan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Penjualan`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_data`
--

CREATE TABLE `tabel_data` (
  `Nip` int(5) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `Tgl_lahir` date DEFAULT NULL,
  `sex` enum('p','w') DEFAULT NULL,
  `alamat` varchar(35) DEFAULT NULL,
  `kota` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `perpustakaan`
--
CREATE DATABASE IF NOT EXISTS `perpustakaan` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `perpustakaan`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `isbn` int(11) NOT NULL,
  `judul` int(11) NOT NULL,
  `id_penulis` int(11) NOT NULL,
  `id_penerbit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bukuu`
--

CREATE TABLE `bukuu` (
  `id_buku` varchar(5) NOT NULL,
  `isbn` varchar(30) DEFAULT NULL,
  `judul` varchar(200) DEFAULT NULL,
  `id_penulis` int(11) DEFAULT NULL,
  `id_penerbit` int(11) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `tahun_terbit` varchar(4) DEFAULT NULL,
  `sinopsis` text,
  `jumlah` int(11) DEFAULT NULL,
  `foto_sampul` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
--
-- Database: `perusahaan`
--
CREATE DATABASE IF NOT EXISTS `perusahaan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `perusahaan`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `NIP` int(25) DEFAULT NULL,
  `NAMA` varchar(35) DEFAULT NULL,
  `GAJI` int(25) DEFAULT NULL,
  `Tgl_Lahir` date DEFAULT NULL,
  `Pendidikan` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`NIP`, `NAMA`, `GAJI`, `Tgl_Lahir`, `Pendidikan`) VALUES
(111401005, 'cholik indrianto', 2500000, '1993-01-01', 'DIII'),
(111401006, 'Dini islami', 2500000, '1993-01-31', 'DIII'),
(111401010, 'Geubrina rizky', 2000000, '1990-12-01', 'DIII'),
(111401043, 'Richart valent', 2800000, '1991-11-15', 'S1'),
(111401001, 'Angga Eriansyah', 3000000, '1992-07-05', 'S1'),
(NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pekerja`
--

CREATE TABLE `pekerja` (
  `NIP` int(25) DEFAULT NULL,
  `NAMA` varchar(35) DEFAULT NULL,
  `GAJI` int(25) DEFAULT NULL,
  `Tgl_Lahir` date DEFAULT NULL,
  `Pendidikan` varchar(15) DEFAULT NULL,
  `jlh_hari` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pekerja`
--

INSERT INTO `pekerja` (`NIP`, `NAMA`, `GAJI`, `Tgl_Lahir`, `Pendidikan`, `jlh_hari`) VALUES
(111401005, 'cholik indrianto', 2500000, '1993-01-01', 'DIII', 24),
(111401006, 'Dini islami', 2500000, '1993-01-31', 'DIII', 22),
(111401010, 'Geubrina rizky', 2000000, '1990-12-01', 'DIII', 20),
(111401043, 'Richart valent', 2800000, '1991-11-15', 'S1', 21),
(111401001, 'Angga Eriansyah', 3000000, '1992-07-05', 'S1', 26);
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

--
-- Dumping data untuk tabel `pma__designer_settings`
--

INSERT INTO `pma__designer_settings` (`username`, `settings_data`) VALUES
('root', '{\"angular_direct\":\"direct\",\"relation_lines\":\"true\",\"snap_to_grid\":\"off\",\"full_screen\":\"on\"}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

--
-- Dumping data untuk tabel `pma__export_templates`
--

INSERT INTO `pma__export_templates` (`id`, `username`, `export_type`, `template_name`, `template_data`) VALUES
(1, 'root', 'table', 'kampus', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"allrows\":\"1\",\"aliases_new\":\"\",\"output_format\":\"sendit\",\"filename_template\":\"@TABLE@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_columns\":\"something\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"json_structure_or_data\":\"data\",\"json_unicode\":\"something\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Struktur tabel @TABLE@\",\"latex_structure_continued_caption\":\"Struktur tabel @TABLE@ (dilanjutkan)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Isi tabel @TABLE@\",\"latex_data_continued_caption\":\"Isi tabel @TABLE@ (dilanjutkan)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_use_transaction\":\"something\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"xml_structure_or_data\":\"data\",\"xml_export_events\":\"something\",\"xml_export_functions\":\"something\",\"xml_export_procedures\":\"something\",\"xml_export_tables\":\"something\",\"xml_export_triggers\":\"something\",\"xml_export_views\":\"something\",\"xml_export_contents\":\"something\",\"yaml_structure_or_data\":\"data\",\"\":null,\"lock_tables\":null,\"csv_removeCRLF\":null,\"csv_columns\":null,\"excel_removeCRLF\":null,\"json_pretty_print\":null,\"htmlword_columns\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_procedure_function\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}'),
(2, 'root', 'server', 'Ukk', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"db_select[]\":[\"#mysql50#tugas praktikum\",\"Bioskop\",\"cookies\",\"crud\",\"crudaja\",\"crudd\",\"crudoop\",\"data_pribadi\",\"dbpenjualan\",\"dbperpus\",\"dbperpus2\",\"db_bloglaravel\",\"db_daerah\",\"detailtrans\",\"galerifoto\",\"instruktur\",\"kampus\",\"kampusku\",\"kampusku3\",\"karyawan\",\"kmps3\",\"lks computer shop\",\"mapel_kuliah\",\"monn\",\"nowsimon\",\"oderbarang\",\"pegawai\",\"pendidikan\",\"Penjualan\",\"perpustakaan\",\"perusahaan\",\"phpmyadmin\",\"raja pratama\",\"schol\",\"sekolah\",\"sekolah9\",\"sekolahh\",\"simon\",\"skolah\",\"smkresto\",\"test\",\"tokosmk\",\"tugas\",\"ujitoko\",\"ukk_galerifoto\",\"universitas\",\"vb_database\",\"webgalerifoto\"],\"aliases_new\":\"\",\"output_format\":\"sendit\",\"filename_template\":\"@SERVER@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_columns\":\"something\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"json_structure_or_data\":\"data\",\"json_unicode\":\"something\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Struktur tabel @TABLE@\",\"latex_structure_continued_caption\":\"Struktur tabel @TABLE@ (dilanjutkan)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Isi tabel @TABLE@\",\"latex_data_continued_caption\":\"Isi tabel @TABLE@ (dilanjutkan)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_use_transaction\":\"something\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"yaml_structure_or_data\":\"data\",\"\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"csv_columns\":null,\"excel_removeCRLF\":null,\"json_pretty_print\":null,\"htmlword_columns\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_drop_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_procedure_function\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

--
-- Dumping data untuk tabel `pma__favorite`
--

INSERT INTO `pma__favorite` (`username`, `tables`) VALUES
('root', '[]');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

--
-- Dumping data untuk tabel `pma__navigationhiding`
--

INSERT INTO `pma__navigationhiding` (`username`, `item_name`, `item_type`, `db_name`, `table_name`) VALUES
('root', 'album', 'table', 'ukk_galerifoto', ''),
('root', 'foto', 'table', 'ukk_galerifoto', ''),
('root', 'foto', 'table', 'webgalerifoto', ''),
('root', 'pma__tracking', 'table', 'phpmyadmin', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data untuk tabel `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"ukk_galerifoto\",\"table\":\"user\"},{\"db\":\"ukk_galerifoto\",\"table\":\"album\"},{\"db\":\"webgalerifoto\",\"table\":\"foto\"},{\"db\":\"ukk_galerifoto\",\"table\":\"likefoto\"},{\"db\":\"ukk_galerifoto\",\"table\":\"komentarfoto\"},{\"db\":\"ukk_galerifoto\",\"table\":\"foto\"},{\"db\":\"dbperpus\",\"table\":\"tabel_buku\"},{\"db\":\"dbperpus2\",\"table\":\"tabel_buku\"},{\"db\":\"ukk_galerifoto\",\"table\":\"unlikefoto\"},{\"db\":\"dbpenjualan\",\"table\":\"tb_stok awal\"}]');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data untuk tabel `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'crud', 'employees', '{\"CREATE_TIME\":\"2023-11-10 17:46:34\",\"col_order\":[0,1,2,3],\"col_visib\":[1,1,1,1]}', '2023-11-17 09:57:13'),
('root', 'crudaja', 'cape', '[]', '2023-11-17 10:40:01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data untuk tabel `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2024-02-27 03:59:56', '{\"Console\\/Mode\":\"show\",\"lang\":\"id\",\"Console\\/Height\":180,\"NavigationWidth\":195}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indeks untuk tabel `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indeks untuk tabel `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indeks untuk tabel `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indeks untuk tabel `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indeks untuk tabel `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indeks untuk tabel `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indeks untuk tabel `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indeks untuk tabel `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indeks untuk tabel `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indeks untuk tabel `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indeks untuk tabel `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indeks untuk tabel `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indeks untuk tabel `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `raja pratama`
--
CREATE DATABASE IF NOT EXISTS `raja pratama` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `raja pratama`;
--
-- Database: `schol`
--
CREATE DATABASE IF NOT EXISTS `schol` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `schol`;
--
-- Database: `sekolah`
--
CREATE DATABASE IF NOT EXISTS `sekolah` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sekolah`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `table anggota`
--

CREATE TABLE `table anggota` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `sekolah9`
--
CREATE DATABASE IF NOT EXISTS `sekolah9` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sekolah9`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_guru`
--

CREATE TABLE `tb_guru` (
  `kode_guru` varchar(10) NOT NULL,
  `Nama_guru` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_guru`
--

INSERT INTO `tb_guru` (`kode_guru`, `Nama_guru`) VALUES
('GR-001', 'permata putri'),
('GR-002', 'dedi lesmana'),
('GR-003', 'reva adriani');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_mapel`
--

CREATE TABLE `tb_mapel` (
  `kode_mapel` varchar(10) NOT NULL,
  `nama_mapel` varchar(25) NOT NULL,
  `jlh_les` int(11) DEFAULT NULL,
  `kode_guru` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_mapel`
--

INSERT INTO `tb_mapel` (`kode_mapel`, `nama_mapel`, `jlh_les`, `kode_guru`) VALUES
('MP-001', 'B.indonesia', 3, 'GR-001'),
('MP-002', 'B.inggris', 3, 'GR-002');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_nilai`
--

CREATE TABLE `tb_nilai` (
  `kode_nilai` int(4) NOT NULL,
  `nis` varchar(10) NOT NULL,
  `kode_mapel` varchar(10) NOT NULL,
  `status` enum('UH','MID','US') DEFAULT NULL,
  `nilai` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_nilai`
--

INSERT INTO `tb_nilai` (`kode_nilai`, `nis`, `kode_mapel`, `status`, `nilai`) VALUES
(1, '202301', 'MP-001', 'MID', '85'),
(2, '202302', 'MP-002', 'MID', '88'),
(3, '202303', 'MP-003', 'MID', '90'),
(4, '202304', 'MP-004', 'MID', '91');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `nis` varchar(10) NOT NULL,
  `nama_siswa` varchar(25) NOT NULL,
  `sex` enum('L','P') DEFAULT NULL,
  `kelas` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_siswa`
--

INSERT INTO `tb_siswa` (`nis`, `nama_siswa`, `sex`, `kelas`) VALUES
('202301', 'annisa putri', 'P', 'XII RPL '),
('202302', 'budi purnama', 'L', 'XII RPL '),
('202303', 'dewi larasari', 'P', 'XII RPL ');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_mapel`
--
ALTER TABLE `tb_mapel`
  ADD PRIMARY KEY (`kode_mapel`);

--
-- Indeks untuk tabel `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD PRIMARY KEY (`kode_nilai`);

--
-- Indeks untuk tabel `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`nis`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_nilai`
--
ALTER TABLE `tb_nilai`
  MODIFY `kode_nilai` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Database: `sekolahh`
--
CREATE DATABASE IF NOT EXISTS `sekolahh` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sekolahh`;
--
-- Database: `simon`
--
CREATE DATABASE IF NOT EXISTS `simon` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `simon`;
--
-- Database: `skolah`
--
CREATE DATABASE IF NOT EXISTS `skolah` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `skolah`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `no_pendaftaran`
--

CREATE TABLE `no_pendaftaran` (
  `No_pendaftaran` int(11) NOT NULL,
  `Nama` text NOT NULL,
  `Tempat` text NOT NULL,
  `Tanggal` int(255) NOT NULL,
  `Agama` text NOT NULL,
  `Jenis_Kelamin` text NOT NULL,
  `Tinggi` int(255) NOT NULL,
  `Alamat` text NOT NULL,
  `Jurusan` text NOT NULL,
  `Nem` int(255) NOT NULL,
  `Sekolah_asal` text NOT NULL,
  `Kota` text NOT NULL,
  `Sttb` int(255) NOT NULL,
  `Ayah` text NOT NULL,
  `Ibu` text NOT NULL,
  `Pekerjaan_ayah` text NOT NULL,
  `Pekerjaan_ibu` text NOT NULL,
  `Alamat_Orangtua` text NOT NULL,
  `Tahun_ajaran` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_admin`
--

CREATE TABLE `tabel_admin` (
  `id_Unsur` int(255) NOT NULL,
  `username` text NOT NULL,
  `password` int(255) NOT NULL,
  `level_akses` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_bagikelas`
--

CREATE TABLE `tabel_bagikelas` (
  `Kode_kelas` int(255) NOT NULL,
  `No_induk` int(255) NOT NULL,
  `Tahun_ajaran` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_daftarulang`
--

CREATE TABLE `tabel_daftarulang` (
  `No_daftarulang` int(255) NOT NULL,
  `No_induk` int(255) NOT NULL,
  `uang_sumbangan` int(255) NOT NULL,
  `biayatotal` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_datakelas`
--

CREATE TABLE `tabel_datakelas` (
  `Kode_kelas` int(11) NOT NULL,
  `Kode_jurusan` int(11) NOT NULL,
  `Nama_kelas` text NOT NULL,
  `kapasitas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_jurusan`
--

CREATE TABLE `tabel_jurusan` (
  `Kode_jurusan` int(255) NOT NULL,
  `Nama_jurusan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_siswaditerima`
--

CREATE TABLE `tabel_siswaditerima` (
  `No_induk` int(255) NOT NULL,
  `No_pendaftaran` int(255) NOT NULL,
  `Tahun_ajaran` year(4) NOT NULL,
  `syarat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `no_pendaftaran`
--
ALTER TABLE `no_pendaftaran`
  ADD PRIMARY KEY (`No_pendaftaran`);

--
-- Indeks untuk tabel `tabel_admin`
--
ALTER TABLE `tabel_admin`
  ADD PRIMARY KEY (`id_Unsur`);

--
-- Indeks untuk tabel `tabel_bagikelas`
--
ALTER TABLE `tabel_bagikelas`
  ADD PRIMARY KEY (`Kode_kelas`,`No_induk`);

--
-- Indeks untuk tabel `tabel_daftarulang`
--
ALTER TABLE `tabel_daftarulang`
  ADD PRIMARY KEY (`No_daftarulang`,`No_induk`);

--
-- Indeks untuk tabel `tabel_datakelas`
--
ALTER TABLE `tabel_datakelas`
  ADD PRIMARY KEY (`Kode_kelas`,`Kode_jurusan`);

--
-- Indeks untuk tabel `tabel_jurusan`
--
ALTER TABLE `tabel_jurusan`
  ADD PRIMARY KEY (`Kode_jurusan`,`Nama_jurusan`);

--
-- Indeks untuk tabel `tabel_siswaditerima`
--
ALTER TABLE `tabel_siswaditerima`
  ADD PRIMARY KEY (`No_induk`,`No_pendaftaran`);
--
-- Database: `smkresto`
--
CREATE DATABASE IF NOT EXISTS `smkresto` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `smkresto`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `IdCustomer` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Password` varchar(16) NOT NULL,
  `Role` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailorder`
--

CREATE TABLE `detailorder` (
  `IdDetail` int(11) NOT NULL,
  `IdOrder` int(11) NOT NULL,
  `IdMenu` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailtrans`
--

CREATE TABLE `detailtrans` (
  `IdDetailTrans` int(11) NOT NULL,
  `Idtrans` int(11) NOT NULL,
  `IdProduct` int(11) NOT NULL,
  `Quant` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `IdMenu` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Price` int(11) NOT NULL,
  `Image` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `orde`
--

CREATE TABLE `orde` (
  `IdOrder` int(11) NOT NULL,
  `IdCustomer` int(11) NOT NULL,
  `Payment` int(11) NOT NULL,
  `SubTotal` datetime NOT NULL,
  `Created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD KEY `IdCustomer` (`IdCustomer`),
  ADD KEY `Name` (`Name`),
  ADD KEY `Phone` (`Phone`),
  ADD KEY `Password` (`Password`),
  ADD KEY `Role` (`Role`),
  ADD KEY `Created_at` (`Created_at`),
  ADD KEY `Update_at` (`Update_at`);

--
-- Indeks untuk tabel `detailorder`
--
ALTER TABLE `detailorder`
  ADD KEY `IdDetail` (`IdDetail`),
  ADD KEY `IdOrder` (`IdOrder`),
  ADD KEY `Quantity` (`Quantity`),
  ADD KEY `Price` (`Price`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD KEY `IdMenu` (`IdMenu`),
  ADD KEY `Name` (`Name`),
  ADD KEY `Image` (`Image`),
  ADD KEY `Price` (`Price`);

--
-- Indeks untuk tabel `orde`
--
ALTER TABLE `orde`
  ADD KEY `IdOrder` (`IdOrder`),
  ADD KEY `IdCustomer` (`IdCustomer`),
  ADD KEY `Payment` (`Payment`),
  ADD KEY `SubTotal` (`SubTotal`),
  ADD KEY `Created_at` (`Created_at`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`IdCustomer`) REFERENCES `detailorder` (`IdDetail`);

--
-- Ketidakleluasaan untuk tabel `detailorder`
--
ALTER TABLE `detailorder`
  ADD CONSTRAINT `detailorder_ibfk_1` FOREIGN KEY (`IdDetail`) REFERENCES `orde` (`IdOrder`);

--
-- Ketidakleluasaan untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`IdMenu`) REFERENCES `detailorder` (`IdDetail`);
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `ambil_mk`
--

CREATE TABLE `ambil_mk` (
  `nip` int(5) DEFAULT NULL,
  `kd_mk` varchar(15) DEFAULT NULL,
  `ruangan` varchar(10) DEFAULT NULL,
  `jml_mhs` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `ambil_mk`
--

INSERT INTO `ambil_mk` (`nip`, `kd_mk`, `ruangan`, `jml_mhs`) VALUES
(3, 'PTI101', 'H5211', 40),
(2, 'PTI102', 'H5212', 45),
(2, 'PTI103', 'H5206', 40),
(1, 'IS101', '17312', 30);

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `customer_id` varchar(30) DEFAULT NULL,
  `customer_name` varchar(30) DEFAULT NULL,
  `customer_address` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_address`) VALUES
('cs001', 'aan', 'pasuruan'),
('cs002', 'hanif', 'banyuwangi'),
('cs003', 'mirza', 'malang'),
('cs004', 'tanti', 'tegal'),
('cs005', 'budie', 'kediri');

-- --------------------------------------------------------

--
-- Struktur dari tabel `instruktur`
--

CREATE TABLE `instruktur` (
  `nip` int(5) DEFAULT NULL,
  `nama_ins` varchar(20) DEFAULT NULL,
  `jurusan` varchar(20) DEFAULT NULL,
  `asal_kota` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `instruktur`
--

INSERT INTO `instruktur` (`nip`, `nama_ins`, `jurusan`, `asal_kota`) VALUES
(1, 'Muhammad Akbar', 'Ilmu Sejarah', 'Malang'),
(2, 'Saichul Fitrian A', 'Ilmu Komputer', 'Malang'),
(3, 'Annafia Oktafian', 'Ilmu Komputer', 'Klaten'),
(4, 'Budy Pratama', 'Ilmu Komputer', 'Magelang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `matakuliah`
--

CREATE TABLE `matakuliah` (
  `kd_mk` varchar(15) DEFAULT NULL,
  `nama_mk` varchar(20) DEFAULT NULL,
  `sks` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `matakuliah`
--

INSERT INTO `matakuliah` (`kd_mk`, `nama_mk`, `sks`) VALUES
('PTI101', 'Algoritma dan pemrog', 3),
('PTI102', 'Basis Data', 3),
('PTI103', 'Visual Basic', 3),
('IS101', 'Sejarah Indonesia', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orderr`
--

CREATE TABLE `orderr` (
  `order_id` varchar(30) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `customer_id` varchar(30) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `orderr`
--

INSERT INTO `orderr` (`order_id`, `order_date`, `customer_id`, `qty`, `amount`) VALUES
('cs001', '0000-00-00', 'cs001', 1, 40000),
('cs002', '0000-00-00', 'cs002', 2, 50000),
('cs003', '0000-00-00', 'cs005', 3, 35000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orderrr`
--

CREATE TABLE `orderrr` (
  `order_id` varchar(30) DEFAULT NULL,
  `order_date` varchar(20) DEFAULT NULL,
  `customer_id` varchar(30) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `orderrr`
--

INSERT INTO `orderrr` (`order_id`, `order_date`, `customer_id`, `qty`, `amount`) VALUES
('cs001', '10-12-2016', 'cs001', 1, 40000),
('cs002', '11-01-2017', 'cs002', 2, 50000),
('cs003', '12-01-2017', 'cs005', 3, 35000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `order_id` varchar(30) DEFAULT NULL,
  `order_date` varchar(30) DEFAULT NULL,
  `customer_id` varchar(30) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `tokosmk`
--
CREATE DATABASE IF NOT EXISTS `tokosmk` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tokosmk`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `kode_barang` varchar(7) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `jumlah` int(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `jumlah`) VALUES
('brg-001', 'indomie', 24),
('brg-002', 'susu indomilk', 6),
('brg-003', 'sprite', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `no_fatur` varchar(10) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `kode_barang` varchar(7) NOT NULL,
  `jumlah_beli` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`no_fatur`, `tanggal`, `kode_barang`, `jumlah_beli`) VALUES
('Fak-001103', '2023-10-18', 'brg-003', 1),
('fak-001104', '2023-10-18', 'brg-002', 6),
('Fak-001123', '2023-10-18', 'brg-001', 5);

--
-- Trigger `penjualan`
--
DELIMITER $$
CREATE TRIGGER `tpenjualan` AFTER INSERT ON `penjualan` FOR EACH ROW begin
update barang set jumlah=new.jumlah_beli where kode_barang=new.kode_barang;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `vpenjualan`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `vpenjualan` (
`no faktur` varchar(10)
,`tanggal` date
,`nama barang` varchar(20)
,`jlh` int(3)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `vpenjualan`
--
DROP TABLE IF EXISTS `vpenjualan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vpenjualan`  AS  select `b`.`no_fatur` AS `no faktur`,`b`.`tanggal` AS `tanggal`,`a`.`nama_barang` AS `nama barang`,`b`.`jumlah_beli` AS `jlh` from (`penjualan` `b` join `barang` `a` on((`b`.`kode_barang` = `a`.`kode_barang`))) ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`no_fatur`);
--
-- Database: `tugas`
--
CREATE DATABASE IF NOT EXISTS `tugas` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tugas`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `Nim` varchar(5) DEFAULT NULL,
  `Nama` varchar(30) DEFAULT NULL,
  `jenis_kelamin` varchar(30) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `ujitoko`
--
CREATE DATABASE IF NOT EXISTS `ujitoko` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ujitoko`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `no_faktur` varchar(20) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `kode_produk` varchar(20) NOT NULL,
  `jlh_beli` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`no_faktur`, `tanggal`, `kode_produk`, `jlh_beli`) VALUES
('fak-0011123', '2023-11-01', 'br-0021123', 2),
('fak-0021123', '2023-11-01', 'br-0031123', 1),
('fak-0031123', '2023-11-01', 'br-0021123', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `kode_produk` varchar(20) NOT NULL,
  `nama_produk` varchar(25) NOT NULL,
  `stok` int(3) DEFAULT NULL,
  `satuan` varchar(15) DEFAULT NULL,
  `harga` int(7) UNSIGNED DEFAULT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`kode_produk`, `nama_produk`, `stok`, `satuan`, `harga`, `regtime`) VALUES
('br-0011123', 'indomie', 78, 'bungkus', 3500, '2023-11-01 04:51:05'),
('br-0021123', 'susu', 24, 'sachet', 25000, '2023-11-01 04:54:27'),
('br-0031123', 'tisu passeo', 10, 'bungkus', 10000, '2023-11-01 04:55:19');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `v_jual`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_jual` (
`no faktur` varchar(20)
,`tanggal` date
,`nama barang` varchar(25)
,`jumlah` int(3)
,`harga` int(7) unsigned
,`total` bigint(20) unsigned
);

-- --------------------------------------------------------

--
-- Struktur untuk view `v_jual`
--
DROP TABLE IF EXISTS `v_jual`;

CREATE ALGORITHM=UNDEFINED DEFINER=`cantika`@`localhost` SQL SECURITY DEFINER VIEW `v_jual`  AS  select `penjualan`.`no_faktur` AS `no faktur`,`penjualan`.`tanggal` AS `tanggal`,`produk`.`nama_produk` AS `nama barang`,`penjualan`.`jlh_beli` AS `jumlah`,`produk`.`harga` AS `harga`,(`penjualan`.`jlh_beli` * `produk`.`harga`) AS `total` from (`produk` join `penjualan` on((`produk`.`kode_produk` = `penjualan`.`kode_produk`))) ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`no_faktur`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode_produk`);
--
-- Database: `ukk_galerifoto`
--
CREATE DATABASE IF NOT EXISTS `ukk_galerifoto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ukk_galerifoto`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `albumid` int(11) NOT NULL,
  `namaalbum` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `tanggalbuat` date NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`albumid`, `namaalbum`, `deskripsi`, `tanggalbuat`, `userid`) VALUES
(1, 'nadeak', 'nadeak', '0000-00-00', 4),
(2, 'HEWAN', 'ANAK ANJING', '2024-02-22', 2),
(3, 'TUMBUHAN', 'TUMBUHAN', '2024-02-22', 2),
(4, 'd', 'foto', '2024-02-24', 10),
(5, 'd', 'fito', '2024-02-24', 10),
(6, 'd', '2134', '2024-02-24', 10),
(7, 'qwe', 'gwe', '2024-02-24', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `fotoid` int(11) NOT NULL,
  `judulfoto` varchar(255) NOT NULL,
  `deskripsifoto` text NOT NULL,
  `tanggalunggah` date NOT NULL,
  `lokasifile` varchar(255) NOT NULL,
  `albumid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`fotoid`, `judulfoto`, `deskripsifoto`, `tanggalunggah`, `lokasifile`, `albumid`, `userid`) VALUES
(1, 'q', 'q', '2024-02-15', '21607-alokff.jpg', 1, 4),
(2, 'ANAK ANJING', 'ANAK ANJING', '2024-02-22', '31547-anakanjing.jpg', 2, 2),
(3, 'ANAK ANJING', 'ANAK ANJING', '2024-02-22', '17043-anakanjing1.jpg', 2, 2),
(4, 'ANAK ANJING', 'ANAK ANJING', '2024-02-22', '26793-anakanjing2.jpg', 2, 2),
(7, 'ultraman', '3rt32tr32', '2024-02-24', '23010-senja.jpg', 4, 10),
(8, 'ultraman', '														ZXDVSD														', '2024-02-27', '24998-walpeper1.jpeg', 4, 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `komentarid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `isikomentar` text NOT NULL,
  `tanggalkomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `likeid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggallike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`likeid`, `fotoid`, `userid`, `tanggallike`) VALUES
(0, 1, 4, '2024-02-22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `unlikefoto`
--

CREATE TABLE `unlikefoto` (
  `unlikeid` int(11) NOT NULL,
  `fotoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `tanggalunlike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `email`, `namalengkap`, `alamat`) VALUES
(2, 'fadel', 'b2f1b83629db8b1b7f0ddc8dc879f7a4', 'fadelsuyaga@gmail.com', 'fadel suyaga', 'taman eden'),
(4, 'adrian', '8c4205ec33d8f6caeaaaa0c10a14138c', 'adrian@gmail.com', 'adrian', 'adrian'),
(9, 'tio', 'fcea920f7412b5da7be0cf42b8c93759', 'harysetio@gmail.com', 'hary setio', 'a'),
(10, 'tio', '827ccb0eea8a706c4c34a16891f84e7b', 'harysetio@gmail.com', 'hary setio', 'a');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`fotoid`),
  ADD KEY `albumid` (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`komentarid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`likeid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `unlikefoto`
--
ALTER TABLE `unlikefoto`
  ADD PRIMARY KEY (`unlikeid`),
  ADD KEY `fotoid` (`fotoid`) USING BTREE,
  ADD KEY `userid` (`userid`) USING BTREE;

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `albumid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `fotoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `komentarid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `unlikefoto`
--
ALTER TABLE `unlikefoto`
  MODIFY `unlikeid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`);

--
-- Ketidakleluasaan untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD CONSTRAINT `foto_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`),
  ADD CONSTRAINT `foto_ibfk_2` FOREIGN KEY (`albumid`) REFERENCES `album` (`albumid`);

--
-- Ketidakleluasaan untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD CONSTRAINT `komentarfoto_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`),
  ADD CONSTRAINT `komentarfoto_ibfk_2` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`);

--
-- Ketidakleluasaan untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD CONSTRAINT `likefoto_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`),
  ADD CONSTRAINT `likefoto_ibfk_2` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`);
--
-- Database: `universitas`
--
CREATE DATABASE IF NOT EXISTS `universitas` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `universitas`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `instruktur`
--

CREATE TABLE `instruktur` (
  `nip` int(5) DEFAULT NULL,
  `nama_ins` varchar(30) DEFAULT NULL,
  `jurusan` varchar(30) DEFAULT NULL,
  `asal_kota` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `instruktur`
--

INSERT INTO `instruktur` (`nip`, `nama_ins`, `jurusan`, `asal_kota`) VALUES
(1, 'Muhammmada Akbar', 'ilmu sejarah', 'malang'),
(2, 'Asichul Fitrian A.', 'ilmu komputer', 'malang'),
(3, 'Annafia Oktafian', 'ilmu komputer', 'klaten'),
(4, 'Budy Pratama', 'ilmu komputer', 'magelang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `matakuliah`
--

CREATE TABLE `matakuliah` (
  `kode_mk` varchar(30) DEFAULT NULL,
  `nama_mk` varchar(30) DEFAULT NULL,
  `sks` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_telp` varchar(20) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(2, 'Irawan', 'irawan', 'adminirawan', '085774137284', 'irawan@gmail.com', 'Jl. Raya Kadu Seungit'),
(3, 'Diana', 'diana', '1234', '085788992919', 'Diana@gmail.com', 'Suka Seneng Cikeusik'),
(4, 'Hazwan', 'hazwan', '123', '085787778811', 'hazwan@gmail.com', 'Cikeusik Pandeglang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_category`
--

CREATE TABLE `tb_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_category`
--

INSERT INTO `tb_category` (`category_id`, `category_name`) VALUES
(14, 'Perjalanan'),
(15, 'Bawah Air'),
(16, 'Hewan Peliharaan'),
(17, 'Satwa Liar'),
(18, 'Makanan'),
(19, 'Olahraga'),
(20, 'Fashion'),
(21, 'Seni Rupa'),
(22, 'Dokumenter'),
(23, 'Arsitektur');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_image`
--

CREATE TABLE `tb_image` (
  `image_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `image_description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `image_status` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_image`
--

INSERT INTO `tb_image` (`image_id`, `category_id`, `category_name`, `admin_id`, `admin_name`, `image_name`, `image_description`, `image`, `image_status`, `date_created`) VALUES
(34, 23, 'Arsitektur', 2, 'Irawan', 'Merancang Kota Modern', '<p>Foto ini menggambarkan kegiatan desain perencanaan membuat kota yang modern berdasarkan ramah lingkungan</p>\r\n', 'foto1701141777.jpg', 1, '2023-11-28 04:58:19'),
(35, 23, 'Arsitektur', 2, 'Irawan', 'Merancang Perumahan Elit', '<p>Foto ini menggambarkan kegiatan desain perencanaan membuat Rumah yang modern, nyaman untuk keluarga</p>\r\n', 'foto1701144257.jpg', 1, '2023-11-28 04:04:17'),
(36, 17, 'Satwa Liar', 3, 'Diana', 'Harimau Sumatra', 'Harimau sumatera (Panthera tigris sumatrae) adalah subspesies harimau yang habitat aslinya di pulau Sumatera. Hidup di hutan hujan tropis Sumatera, harimau ini adalah pemakan daging yang ulung. Dengan kecepatan lari hampir 40 mil per jam, mereka adalah predator yang tangguh di alam liar. Kemampuannya berburu, terutama di malam hari, memungkinkan mereka untuk mengintai mangsa dengan diam-diam sebelum menerkam dengan cepat.', 'foto1701147078.jpg', 1, '2023-11-28 04:51:18'),
(37, 17, 'Satwa Liar', 3, 'Diana', 'Badak Jawa', 'Badak Jawa (Rhinoceros sondaicus) adalah jenis satwa langka yang masuk kedalam 25 spesies prioritas utama konservasi Pemerintah Indonesia. Badak Jawa dapat hidup hingga 30-45 tahun di habitat aslinya. Mereka biasa tinggal di hutan hujan dataran rendah, padang rumput basah, dan dataran banjir yang luas. Badak ini merupakan makhluk yang suka menyendiri, kecuali saat pacaran dan saat membesarkan anak.', 'foto1701147926.jpg', 1, '2023-11-28 05:05:26'),
(38, 16, 'Hewan Peliharaan', 3, 'Diana', 'Kucing Angora', 'Anggora adalah kucing dengan ciri khas berbulu panjang yang indah. Anggora memiliki tubuh yang sedang dengan badan berotot yang panjang, ramping, langsing dan elegan. Anggora memiliki hidung yang panjang, kepala yang berbentuk segitiga, serta telinga yang panjang, lebar, dan berbentuk segitiga.', 'foto1701148582.jpg', 1, '2023-11-28 05:16:22'),
(39, 16, 'Hewan Peliharaan', 3, 'Diana', 'Ayam Kampung', 'Ayam kampung adalah kualitas daging nya yang memang lebih unggul di bandingkan dengan daging ayam lain nya, sehingga tidak heran jika rasa nya juga jauh lebih enak di bandingkan ayam lain.', 'foto1701148797.jpg', 1, '2023-11-28 05:19:57'),
(40, 14, 'Perjalanan', 4, 'Hazwan', 'Pantai Carita', 'Pantai Carita merupakan objek wisata yang terletak di Kabupaten Pandeglang. Fasilitas di Pantai Carita cukup lengkap yaitu Banana boat, snorkling, papan seluncur, diving, dan fasilitas lainnya. Banyak juga penginapan-penginapan sepanjang pesisir pantai dan atau rumah-rumah warga yang difungsikan untuk penginapan.', 'foto1701150076.jpg', 1, '2023-11-28 05:41:16'),
(41, 14, 'Perjalanan', 4, 'Hazwan', 'Curug Putri', 'Curug Putri Carita Pandeglang ini unik banget karena terbentuk dari lava yang membeku dan kemudian menjadi aliran sungai dengan batuan cantik.', 'foto1701150304.jpg', 1, '2023-11-28 05:45:04'),
(42, 17, 'Satwa Liar', 3, 'Diana', 'Singa Afrika', 'Singa adalah binatang yang menakutkan , tubuhnya besar, gesit dan garang, buas dan menyeramkan. Singa memiliki taring yang gampang melumatkan mangsanya, punya kuku yang kuat yang mampu menerkam mangsa hingga tak berdaya, dan mencabik- cabiknya. Singa sering digunakan untuk mewakili kekuatan, kegarangan dan kebuasan.', 'foto1701150517.jpg', 1, '2023-11-28 05:48:37');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indeks untuk tabel `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indeks untuk tabel `tb_image`
--
ALTER TABLE `tb_image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tb_category`
--
ALTER TABLE `tb_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `tb_image`
--
ALTER TABLE `tb_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_image`
--
ALTER TABLE `tb_image`
  ADD CONSTRAINT `tb_image_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tb_admin` (`admin_id`),
  ADD CONSTRAINT `tb_image_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `tb_category` (`category_id`);
--
-- Database: `vb_database`
--
CREATE DATABASE IF NOT EXISTS `vb_database` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `vb_database`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` varchar(6) NOT NULL,
  `nama_karyawan` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `alamat`, `telepon`) VALUES
('AAT001', 'MUHAMMAD', 'JALAN JENGKOL NO.3', '081236387850'),
('AAT002', 'NAGITA SLAVINA', 'JALAN KEBON JERUK NO.8', '0814653434432');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);
--
-- Database: `webgalerifoto`
--
CREATE DATABASE IF NOT EXISTS `webgalerifoto` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `webgalerifoto`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `fotoid` int(11) NOT NULL,
  `judulfoto` varchar(225) NOT NULL,
  `deskripsifoto` text NOT NULL,
  `tanggalungguh` date NOT NULL,
  `lokasifile` varchar(225) NOT NULL,
  `albumid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`fotoid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `fotoid` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
