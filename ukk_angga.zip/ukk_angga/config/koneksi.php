<?php 
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'ukk_galerifoto';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);



?>